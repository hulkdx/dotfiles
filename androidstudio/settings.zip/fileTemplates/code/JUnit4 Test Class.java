import androidx.arch.core.executor.testing.InstantTaskExecutorRule;
import fi.virta.rules.RxImmediateSchedulerRule;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.ArgumentCaptor;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import static org.hamcrest.CoreMatchers.*;
import static org.mockito.ArgumentMatchers.*;

#parse("File Header.java")
public class ${NAME} {  
  // region constants ----------------------------------------------------------------------------
  // endregion constants -------------------------------------------------------------------------
  
  // region helper fields ------------------------------------------------------------------------
  
  @Rule public MockitoRule mockitoJUnit = MockitoJUnit.rule();
  @Rule public RxImmediateSchedulerRule rxImmediateSchedulerRule = RxImmediateSchedulerRule();
  @Rule public InstantTaskExecutorRule instantTaskExecutorRule = InstantTaskExecutorRule();
  
  // endregion helper fields ---------------------------------------------------------------------
  
  private ${CLASS_NAME} SUT;
  
  @Before
  public void setup() {
    SUT = new ${CLASS_NAME}();
  }
  
  // region helper methods -----------------------------------------------------------------------
  // endregion helper methods --------------------------------------------------------------------

}