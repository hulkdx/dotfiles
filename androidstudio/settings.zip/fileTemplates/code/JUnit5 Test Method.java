@org.junit.jupiter.api.Test
@org.junit.Test
public void ${NAME}() throws Exception {
  // Arrange
  // Act
  SUT.();
  // Assert
}